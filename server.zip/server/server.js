var express = require('express');
var app = express();
var cors = require('cors');
var { Housemate, Order } = require('./db');
const rateLimit = require("express-rate-limit");
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100 // limit each IP to 100 requests per windowMs
});

app.use(cors());
app.use(limiter);

app.get('/current-person', (req, res) => {
    Order.findOne({}, (err, result) => {
        var { order } = result;
        Housemate.findOne({index: order % 6}, (err, mate) => {
            res.json(mate);
        })
    })
})

app.get('/next-person', (req, res) => {
    Order.findOneAndUpdate({}, { $inc: { order: 1 } }, {new: true}, (err, doc) => {
        var { order } = doc;
        Housemate.findOne({index: order % 6}, (err, mate) => {
            res.json(mate);
        })
    })
})

app.get('/webhook', (req, res) => {

    // Your verify token. Should be a random string.
    let VERIFY_TOKEN = "<YOUR_VERIFY_TOKEN>"
    // Parse the query params
    let mode = req.query['hub.mode'];
    let token = req.query['hub.verify_token'];
    let challenge = req.query['hub.challenge'];
    // Checks if a token and mode is in the query string of the request
    if (mode && token) {
    
      // Checks the mode and token sent is correct
    if (mode === 'subscribe' && token === VERIFY_TOKEN) {
        
        // Responds with the challenge token from the request
        console.log('WEBHOOK_VERIFIED');
        res.status(200).send(challenge);
    } else {
        // Responds with '403 Forbidden' if verify tokens do not match
        res.sendStatus(403);      
        }
    }
});

app.listen(process.env.PORT || '3000', () => {
    console.log('app is listening at port 3000')
})