var ordering = ['JPanda', 'Wesley','Amal', 'William', 'Jeremy', 'Srikar'];

var { Order, Housemate } = require('./db');
var housemates = ordering.map(function(mate, index){ 
    return {name : mate, index}
})

insert(Housemate, housemates, (err, res) => {
    insert(Order, {order: 0}, (err, res) => {
        console.log('success!');
    })
})

function insert(model, object, cb){
    model.insertMany(object)
        .then(res => {
            console.log(res);
            cb(null, res);
        })
        .catch(err => {
            console.log(err);
            cb(err)
        })
}