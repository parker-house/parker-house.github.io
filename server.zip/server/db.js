var mongoose = require('mongoose');

mongoose.Promise = global.Promise;
mongoose.set('useFindAndModify', false);

mongoose.connect(process.env.MONGODB_URI || "mongodb://localhost:27017/test",
{ useNewUrlParser: true });

var HousemateSchema = new mongoose.Schema({
    name: {
        type: String,
        unique: true
    },
    index: {
        type: Number,
        unique: true
    }
})

var OrderSchema = new mongoose.Schema({
    order: {
        type: Number
    }
})

var Housemate = mongoose.model('Housemates', HousemateSchema);
var Order = mongoose.model('Orders', OrderSchema);

module.exports = {mongoose, Housemate, Order};
